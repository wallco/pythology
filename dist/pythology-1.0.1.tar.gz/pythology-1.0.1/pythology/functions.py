def teste():
    print ('Teste biblioteca')